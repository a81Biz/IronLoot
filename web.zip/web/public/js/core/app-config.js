/**
 * Iron Loot - Runtime Configuration
 * To be loaded before any other core scripts.
 */
window.APP_CONFIG = {
    apiUrl: "/api/v1"
};
