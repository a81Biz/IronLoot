/**
 * Iron Loot - API Route Catalog
 * Centralized registry of all API endpoints.
 * All paths must be relative to the API Client's BASE_URL (currently /api/v1).
 */
window.ApiRoutes = {
    auth: {
        register: "/auth/register",
        login: "/auth/login",
        logout: "/auth/logout",
        refresh: "/auth/refresh",
        verifyEmail: "/auth/verify-email",
        resendVerification: "/users/me/resend-verification", // Verified: In UsersController
        forgotPassword: "/auth/forgot-password",
        resetPassword: "/auth/reset-password",
        changePassword: "/auth/change-password",
        me: "/auth/me"
    },
    users: {
        me: "/users/me", // GET, PATCH
        stats: "/users/me/stats",
        settings: "/users/me/settings", // GET, PATCH
        enableSeller: "/users/me/enable-seller",
        verificationStatus: "/users/me/verification-status",
        publicProfile: (id) => `/users/${id}`,
        ratings: (id) => `/users/${id}/ratings` // In RatingsController
    },
    auctions: {
        list: "/auctions", // GET
        create: "/auctions", // POST
        detail: (id) => `/auctions/${id}`, // GET
        update: (id) => `/auctions/${id}`, // PATCH
        publish: (id) => `/auctions/${id}/publish`, // POST
        end: (id) => `/auctions/${id}/end`,
        placeBid: (id) => `/auctions/${id}/bids`, // POST (BidsController)
        listBids: (id) => `/auctions/${id}/bids` // GET (BidsController)
    },
    bids: {
        myActive: "/bids/my-active",
        myHistory: "/bids/my-history"
    },
    orders: {
        list: "/orders", // GET (role=buyer|seller)
        detail: (id) => `/orders/${id}`, // GET
        updateStatus: (id) => `/orders/${id}/status`,
        confirmReceived: (id) => `/orders/${id}/confirm-receipt`,
        ship: (id) => `/orders/${id}/ship`,
        cancel: (id) => `/orders/${id}/cancel`,
        sellerOrders: "/orders/seller-orders"
    },
    wallet: {
        balance: "/wallet/balance",
        deposit: "/wallet/deposit",
        withdraw: "/wallet/withdraw",
        history: "/wallet/history"
    },
    watchlist: {
        list: "/watchlist", // GET
        add: "/watchlist", // POST
        remove: (id) => `/watchlist/${id}` // DELETE
    },
    notifications: {
        list: "/notifications",
        unreadCount: "/notifications/unread-count",
        readAll: "/notifications/read-all", // PATCH
        markRead: (id) => `/notifications/${id}/read` // PATCH
    },
    disputes: {
        create: "/disputes", // POST
        list: "/disputes", // GET
        detail: (id) => `/disputes/${id}`,
        // Extracted from service:
        addMessage: (id) => `/disputes/${id}/messages`,
        uploadEvidence: (id) => `/disputes/${id}/evidence`,
        resolve: (id) => `/disputes/${id}/resolve`
    },
    ratings: {
        create: "/ratings", // POST
        listByUser: (userId) => `/users/${userId}/ratings`
    },
    webViews: {
        // Confirmed via WebViewsController: @Controller() at root + @Get('payments')
        payments: "/payments", 
        wonAuctions: "/won-auctions",
        privacy: "/privacy",
        terms: "/terms"
    },
    seller: {
       // Extracted from seller.service.js: /seller/dashboard, /seller/profile
       // I did not see a SellerController in the root `modules`.
       // It might be inside `users`? or `auctions`?
       // `users` had `enableSeller`.
       // `api/src/modules/seller` via list_dir? Np, I didn't see `seller` directory.
       // I saw `users`, `auctions`, etc.
       // `seller.service.js` used: Api.get('/seller/dashboard').
       // This endpoint might NOT exist or I missed a controller.
       // I will add it to routes as requested by existing JS, but it's suspicious.
       dashboard: "/seller/dashboard",
       profile: "/seller/profile"
    }
};
