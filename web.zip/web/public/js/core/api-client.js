/**
 * Iron Loot - API Client
 * Wraps HTTP requests and handles token injection/storage.
 * Does NOT contain domain logic.
 */

const ApiClient = (function() {
  // Configuration
  const BASE_URL = window.APP_CONFIG?.apiUrl || '/api/v1';
  const TIMEOUT = 30000;

  // State - Managed by LocalStorage (Token-Based)
  const STORAGE_KEY = 'ironloot_auth_tokens';

  /**
   * Set authentication tokens
   */
  function setTokens(tokens) {
    if (!tokens) return;
    console.log('[ApiClient] Saving tokens:', tokens);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tokens));
  }

  /**
   * Clear all tokens
   */
  function clearTokens() {
    localStorage.removeItem(STORAGE_KEY);
  }

  /**
   * Get current Access Token
   */
  function getAccessToken() {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (!stored) {
            console.warn('[ApiClient] No tokens in localStorage');
            return null;
        }
        const tokens = JSON.parse(stored);
        if (!tokens.accessToken) {
             console.error('[ApiClient] Stored tokens missing accessToken:', tokens);
             return null;
        }
        return tokens.accessToken;
    } catch (e) {
        console.error('[ApiClient] Token parse error', e);
        return null; // Invalid format
    }
  }

  /**
   * Helper: Build full URL
   */
  function _buildUrl(path, params = {}) {
    // Determine Base URL (handling leading/trailing slashes)
    let base = BASE_URL.endsWith('/') ? BASE_URL.slice(0, -1) : BASE_URL;
    let endpoint = path.startsWith('/') ? path : '/' + path;
    const url = new URL(base + endpoint, window.location.origin);
    
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        url.searchParams.append(key, String(value));
      }
    });
    
    return url.toString();
  }

  /**
   * Helper: Get Headers
   */
  function _getHeaders(path) {
    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
    
    // Inject Bearer Token
    const token = getAccessToken();
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    } else {
        console.warn('[ApiClient] No Access Token found in localStorage for request to:', path);
    }

    const csrfToken = Utils.getCookie('XSRF-TOKEN');
    if (csrfToken) {
       headers['x-xsrf-token'] = csrfToken;
    }
    return headers;
  }

  /**
   * Core request method
   */
  async function request(method, path, body = null, options = {}) {
    const url = _buildUrl(path, options.params);
    const headers = _getHeaders(path);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), TIMEOUT);

    const fetchOptions = {
      method,
      headers,
      signal: controller.signal,
      credentials: 'include',
    };

    if (body && method !== 'GET') {
      fetchOptions.body = JSON.stringify(body);
    }

    try {
      const response = await fetch(url, fetchOptions);
      clearTimeout(timeoutId);

      // Parse response
      let data;
      const contentType = response.headers.get('content-type');
      if (contentType?.includes('application/json')) {
        data = await response.json();
      } else {
        data = await response.text();
      }

      const traceId = response.headers.get('x-trace-id');

      // --- CRITICAL: 401 Handling (No Loops) ---
      if (response.status === 401) {
        console.warn('[Api] 401 Unauthorized. Clearing tokens.');
        clearTokens();
        // Emit event so AuthState can react (clean state)
        window.dispatchEvent(new CustomEvent('auth:cleared')); 
        
        // Throw error to stop flow, but include data
        const err = new Error(data?.message || 'Unauthorized');
        err.statusCode = 401;
        err.data = data; // Attach backend error details
        throw err;
      }

      if (!response.ok) {
        const error = new Error(data?.message || 'Request failed');
        error.statusCode = response.status;
        error.data = data;
        error.traceId = traceId;
        throw error;
      }

      // Return unified response
      return { data, status: response.status, accessToken: data?.accessToken };
    } catch (error) {
      clearTimeout(timeoutId);
      if (error.name === 'AbortError') {
         throw new Error('Request timeout');
      }
      throw error;
    }
  }

  // --- Cookie Helpers ---
  // --- Cookie Helpers Removed ---

  // Public Interface
  return {
    setTokens,
    clearTokens,
    getAccessToken,
    isAuthenticated: () => false, // Handled by AuthState
    
    get: (path, options) => request('GET', path, null, options),
    post: (path, body, options) => request('POST', path, body, options),
    patch: (path, body, options) => request('PATCH', path, body, options),
    put: (path, body, options) => request('PUT', path, body, options),
    delete: (path, options) => request('DELETE', path, null, options)
  };
})();

window.Api = ApiClient;
